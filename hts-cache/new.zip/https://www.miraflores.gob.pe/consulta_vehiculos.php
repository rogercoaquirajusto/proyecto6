<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>MUNICIPALIDAD DE MIRAFLORES :: Consulta de vehiculos en Deposito Municipal</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<style type="text/css">
		body{
			background: #f0eff5;
		}
		.barraAzul{
			background: #1f71b7;
			padding: 20px 0 !important;
			box-shadow: 3px;
			-webkit-box-shadow: 2px 2px 4px 0px rgba(33,33,33,.2);
		}
		div{
			padding: 0px !important;
		}
	</style>
</head>
<body>
	<div class="container-fluid row">
		<div class="col-md-3">
			<div class="barraAzul">&nbsp;</div>
		</div>
		<div class="col-md-6">
			<div class="col-sm-6" style="position: absolute; z-index: 10; color: #fff; right: 0px; margin-top: 0; margin-right: 10px">
<div>Depósito Municipal</div>
				<i class="glyphicon glyphicon-map-marker"></i> Pasaje Recabarraca s/n, Surquillo <br>(Espalda Luz del Sur, cuadra 3 de Domingo Orue)<br><i class="glyphicon glyphicon-phone"></i>734-3496</div>
			<iframe src="https://digital.miraflores.gob.pe:8443/miraflores/consulta-vehicular.muni" width="100%" height="3500" frameborder="0"></iframe>
		</div>
		<div class="col-md-3">
			<div class="barraAzul">&nbsp;</div>
		</div>
	</div>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>